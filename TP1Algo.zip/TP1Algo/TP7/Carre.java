package TP7;

import TP6.*;
import TP4.Vecteur3D;

/**
 * Write a description of class carr� here.
 *
 * @author HIND RIME
 * @version 15/04/2019
 */
public class Carre extends Objet
{
    // instance variables - replace the example below with your own
    private int x;

    Transformation m_transformationBase;

    /**
     * Constructor for objects of class carr�
     */
    public Carre(Noeud _parent)
    {
        super(_parent);
        
        String textureCube = "/TP6/res/blanc.jpg";
        
        // on instancie un transformation de base et quatre carr�s qui seront d�clar�s 
        // comme enfants (graphe de sc�ne) de cette transformation
        Vecteur3D transformationBase = new Vecteur3D(0.0f,0.0f,0.0f);
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricePelle[][] =     {{0, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
                                    {3, 5, 4, 4, 3, 0, 0, 0, 0, 0, 0, 0, 0},
                                    {3, 4, 5, 4, 4, 3, 0, 0, 0, 0, 0, 0, 0},
                                    {3, 4, 4, 5, 4, 4, 3, 0, 0, 0, 0, 0, 0},
                                    {0, 3, 4, 4, 5, 1, 0, 0, 0, 0, 0, 0, 0},
                                    {0, 0, 3, 4, 1, 2, 1, 0, 0, 0, 0, 0, 0},
                                    {0, 0, 0, 3, 0, 1, 2, 1, 0, 0, 0, 0, 0},
                                    {0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0},
                                    {0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0},
                                    {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0},
                                    {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0},
                                    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1},
                                    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0}};

        for(int i=0; i<12;  i++){
            for(int j=0;j<12;j++){
                if (matricePelle[i][j]!=0){
                    switch (matricePelle[i][j]){
                        case 1 : textureCube = "/TP6/res/marron_fonce.jpg";
                        break;
                        case 2 : textureCube = "/TP6/res/marron_clair.jpg";
                        break;
                        case 3 : textureCube = "/TP6/res/bleu_fonce.jpg";
                        break;
                        case 4 : textureCube = "/TP6/res/bleu_clair.jpg";
                        break;
                        case 5 : textureCube = "/TP6/res/bleu_moyen.jpg";
                        break;

                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i-13, 2*j-13, 0.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
    }

    /**
     * La m�thode dessine dessine les quatre carr�s que nous avons in
     * instanci� dans le constructeur
     *
     */

    public void dessine()
    {
        // ici il faut dessiner quelquechose. Le quelque chose en question est intanci� 
        // dans le construteur de la classe carr� 
        m_transformationBase.affiche();
    }
}