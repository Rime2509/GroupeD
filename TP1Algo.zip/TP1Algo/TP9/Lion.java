package TP9;


import TP6.*;
import TP4.Vecteur3D;

/**
 * Write a description of class carr� here.
 *
 * @author HIND RIME
 * @version 15/04/2019
 */
public class Lion extends Objet
{
    // instance variables - replace the example below with your own
    private int x;

    Transformation m_transformationBase;

    /**
     * Constructor for objects of class carr�
     */
    public Lion(Noeud _parent)
    {
        super(_parent);
        
        String textureCube = "/TP6/res/blanc.jpg";
        
        // on instancie un transformation de base et quatre carr�s qui seront d�clar�s 
        // comme enfants (graphe de sc�ne) de cette transformation
        Vecteur3D transformationBase = new Vecteur3D(0.0f,0.0f,0.0f);
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricehair1[][] =     {{1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}};

        for(int i=0; i<7;  i++){
            for(int j=0;j<7;j++){
                if (matricehair1[i][j]!=0){
                    switch (matricehair1[i][j]){
                        case 1 : textureCube = "/TP6/res/marron_fonce.jpg";
                        
                        break;

                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, 2.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
       
        
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricehair2[][] =      {{1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}, 
                                    {1, 1, 1, 1, 1, 1, 1}};

        for(int i=0; i<7;  i++){
            for(int j=0;j<7;j++){
                if (matricehair2[i][j]!=0){
                    switch (matricehair2[i][j]){
                        case 1 : textureCube = "/TP6/res/marron_fonce.jpg";
                        
                        break;

                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, 3.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matriceears[][] =      {{0, 0, 0, 2, 2}, 
                                    {2, 2, 2, 2, 2},
                                    {2, 2, 2, 2, 0},
                                    {2, 2, 2, 2, 0},
                                    {2, 2, 2, 2, 0},
                                    {2, 2, 2, 2, 2}, 
                                    {0, 0, 0, 2, 2}};
        for(int i=0; i<7;  i++){
            for(int j=0;j<5;j++){
                if (matriceears[i][j]!=0){
                    switch (matriceears[i][j]){
                        case 2 : textureCube = "/TP6/res/marron_clair.jpg";
                        
                        break;

                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j+2, 5.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        
        
        
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matriceface[][] =      {{2, 2, 3, 2},
                                    {2, 2, 4, 2},
                                    {2, 2, 2, 2},
                                    {2, 2, 4, 2},
                                    {2, 2, 3, 2}};
        for(int i=0; i<5;  i++){
            for(int j=0;j<4;j++){
                if (matriceface[i][j]!=0){
                    switch (matriceface[i][j]){
                        case 2 : textureCube = "/TP6/res/marron_clair.jpg";
                        break;
                        case 3 : textureCube = "/TP6/res/blanc.jpg";
                        break;
                        case 4 : textureCube = "/TP6/res/noir.jpg";
                        break;

                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i+2, 2*j+2, 6.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricenose[][] =      {{3, 4}};
                                   
                                   
        for(int i=0; i<1;  i++){
            for(int j=0;j<2;j++){
                if (matricenose[i][j]!=0){
                    switch (matricenose[i][j]){
                        
                        case 3 : textureCube = "/TP6/res/rose.jpg";
                        break;
                        case 4 : textureCube = "/TP6/res/noir.jpg";
                        break;

                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i+6, 2*j+2,7.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricebody[][] =     {{2,1,1,1,0,0,0,0},
                                   {2,1,1,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {2,1,1,1,1,1,1,1},
                                   {2,1,1,1,0,0,0,0}};
                                   
                                   
      
        for(int i=0; i<7;  i++){
            for(int j=0;j<8;j++){
                if (matricebody[i][j]!=0){
                    switch (matricebody[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                        case 2 : textureCube = "/TP6/res/noir.jpg";
                        break;
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j-2, 2.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricebody1[][] =    {{2,1,1,1,0,0,0,0},
                                   {2,1,1,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {2,1,1,1,1,1,1,1},
                                   {2,1,1,1,0,0,0,0}};
                                   
                                   
        for(int i=0; i<7;  i++){
            for(int j=0;j<8;j++){
                if (matricebody1[i][j]!=0){
                    switch (matricebody1[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                        case 2 : textureCube = "/TP6/res/noir.jpg";
                        break;
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j-2, 1.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricebody2[][] =  {
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1}
                                   };
                                   
                                   
  for(int i=0; i<5;  i++){
            for(int j=0;j<5;j++){
                if (matricebody2[i][j]!=0){
                    switch (matricebody2[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                        
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, 0.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricebody3[][] =  {
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1}
                                   };
                                   
                                   
                                   
      for(int i=0; i<5;  i++){
            for(int j=0;j<5;j++){
                if (matricebody3[i][j]!=0){
                    switch (matricebody3[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                      
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, -1.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        m_transformationBase = new Translation(_parent,transformationBase);


        int matricebody4[][] =  {
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1}
                                   };
                                   
                                   
                                   
        for(int i=0; i<5;  i++){
            for(int j=0;j<5;j++){
                if (matricebody4[i][j]!=0){
                    switch (matricebody4[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                        
                        
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, -2.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
         m_transformationBase = new Translation(_parent,transformationBase);


        int matricebody5[][] =  {
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1}
                                   };
                                   
                                   
                                   
        for(int i=0; i<5;  i++){
            for(int j=0;j<5;j++){
                if (matricebody5[i][j]!=0){
                    switch (matricebody5[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                        
                       
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, -3.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        m_transformationBase = new Translation(_parent,transformationBase);

        int matricebody8[][] =  {
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1},
                                   {1,1,1,1,1}
                                   };  
                                   
                                   
        for(int i=0; i<5;  i++){
            for(int j=0;j<5;j++){
                if (matricebody8[i][j]!=0){
                    switch (matricebody8[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                        case 2 : textureCube = "/TP6/res/noir.jpg";
                        break;
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, -4.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        m_transformationBase = new Translation(_parent,transformationBase);

        int matricebody6[][] =    {{2,1,1,1,0,0,0,0},
                                   {2,1,1,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {2,1,1,1,1,1,1,1},
                                   {2,1,1,1,0,0,0,0}};
                                   
                                   
        for(int i=0; i<7;  i++){
            for(int j=0;j<8;j++){
                if (matricebody6[i][j]!=0){
                    switch (matricebody6[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                        case 2 : textureCube = "/TP6/res/noir.jpg";
                        break;
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, -5.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        m_transformationBase = new Translation(_parent,transformationBase);

        int matricebody7[][] =    {{2,1,1,1,0,0,0,0},
                                   {2,1,1,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {0,0,0,1,1,1,1,1},
                                   {2,1,1,1,1,1,1,1},
                                   {2,1,1,1,0,0,0,0}};
                                   
                                   
        for(int i=0; i<7;  i++){
            for(int j=0;j<8;j++){
                if (matricebody7[i][j]!=0){
                    switch (matricebody7[i][j]){
                        
                        case 1 : textureCube = "/TP6/res/marron_moy.jpg";
                        break;
                        case 2 : textureCube = "/TP6/res/noir.jpg";
                        break;
                        
                    }
                    Vecteur3D vecteur1 = new Vecteur3D(2*i, 2*j, -6.0f);
                    Transformation translation1 = new Translation(_parent,vecteur1);
                    CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                }
            }
        }
        
        
        
          // m_transformationBase = new Translation(_parent,transformationBase);
        
        
        


        // int matriceterre[][] =                { {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5},
                                                // {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5}};
                                    
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                                   // // {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
                                   
                                   
        // for(int i=0; i<30;  i++){
            // for(int k=0; k<30;k++){
                // if (matriceterre[i][k]!=0){
                    // switch (matriceterre[i][k]){
                        
                        // case 5 : textureCube = "/TP6/res/terre.jpg";
                        // break;
                        
                        

                    // }
                    // Vecteur3D vecteur1 = new Vecteur3D(2*i+15, -7 , k-28 );
                    // Transformation translation1 = new Translation(_parent,vecteur1);
                    // CubeTexture cube = new CubeTexture(translation1, textureCube);
                   
                // }
            // }
        // }
    }

    /**
     * La m�thode dessine dessine les quatre carr�s que nous avons in
     * instanci� dans le constructeur
     *
     */

    public void dessine()
    {
        // ici il faut dessiner quelquechose. Le quelque chose en question est intanci� 
        // dans le construteur de la classe carr� 
        m_transformationBase.affiche();
    }
}